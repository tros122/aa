# esx_jk_drugs -- Base code from ESX ORG, rest coded by JiminyKroket

ESX ORG esx_drugs 2.0.0 reworked with all old drugs and new ones, implemented usable drugs and effects for all.

Make sure to remove any other mods that add effects to drugs or liquor, import the SQL and set your config options.

Enjoy
