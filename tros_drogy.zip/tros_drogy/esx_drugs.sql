

INSERT INTO `items` (`name`, `label`, `limit`, `rare`, `can_remove`) VALUES
	('cannabis', 'Cannabis', 50, 0, 1),
	('marijuana', 'Marijuana', 250, 0, 1),
	('coca', 'CocaPlant', 150, 0, 1),
	('cocaine', 'Coke', 50, 0, 1),
	('ephedra', 'Ephedra', 100, 0, 1),
	('ephedrine', 'Ephedrine', 100, 0, 1),
	('poppy', 'Poppy', 100, 0, 1),
	('opium', 'Opium', 50, 0, 1),
	('meth', 'Meth', 25, 0, 1),
	('heroine', 'Heroine', 10, 0, 1),
	('beer', 'Beer', 30, 0, 1),
	('tequila', 'Tequila', 10, 0, 1),
	('vodka', 'Vodka', 10, 0, 1),
	('whiskey', 'Whiskey', 10, 0, 1),
	('crack', 'Crack', 25, 0, 1),
	('drugtest', 'DrugTest', 10, 0, 1),
	('breathalyzer', 'Breathalyzer', 10, 0, 1),
	('fakepee', 'Fake Pee', 5, 0, 1),
	('pcp', 'PCP', 25, 0, 1),
	('dabs', 'Dabs', 50, 0, 1),
	('painkiller', 'Painkiller', 10, 0, 1),
	('narcan', 'Narcan', 10, 0, 1)

;
